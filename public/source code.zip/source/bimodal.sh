#!/bin/sh

make clean ; make 

for ((i=7 ; i<=16 ; i++)) ; do
    rm -f op.$i
done;

for j in gcc jpeg perl ; do
    rm -f bimodal.points.$j
done;

for j in gcc jpeg perl ; do
    for ((i=7 ; i<=16 ; i++)) ; do
        trace_file="../resource/"$j"_trace.txt"
	./sim bimodal $i $trace_file > op.$i

        total_branch=`cat op.$i | grep "number of predictions" | awk '{print $4}'`
        mis_number=`cat op.$i | grep "number of mispredictions" | awk '{print $4}'`
	mispred_rate=`cat op.$i | grep "misprediction rate" | awk '{print $3}' | cut -d '%' -f 1`

        echo -e "$i \t $total_branch \t $mis_number \t $mispred_rate" >> 7-16-bimodal.points.$j
    done;
done;

for ((i=7 ; i<=16 ; i++)) ; do
    rm -f op.$i
done;

make clean ; 



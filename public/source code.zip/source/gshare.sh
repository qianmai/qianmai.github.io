#!/bin/sh

make clean ; make 

for ((i=7 ; i<=16 ; i++)) ; do
	for ((j=2 ; j<=$i ; j=j+2)) ; do
		rm -f op.$i.$j
	done;
done;

for file in gcc jpeg perl ; do
	rm -f gshare.points.$file
done;

for file in gcc jpeg perl ; do
    for ((i=7 ; i<=16 ; i++)) ; do 
        for ((j=2 ; j<=$i ; j=j+2)) ; do
	    trace_file="../resource/"$file"_trace.txt"
	        ./sim gshare $i $j $trace_file > op.$i.$j
               
                total_branch=`cat op.$i.$j | grep "number of predictions" | awk '{print $4}'`
                mis_number=`cat op.$i.$j | grep "number of mispredictions" | awk '{print $4}'` 
		mispred_rate=`cat op.$i.$j | grep "misprediction rate" | awk '{print $3}' | cut -d '%' -f 1`

		echo -e "$i \t $j \t $total_branch \t $mis_number \t $mispred_rate" >> g7-16-gshare.points.$file
		# echo "$i $j $trace_file"
	done;
    done;
done;

for ((i=7 ; i<=16 ; i++)) ; do
	for ((j=2 ; j<=$i ; j=j+2)) ; do
		rm -f op.$i.$j
	done;
done;

make clean ;



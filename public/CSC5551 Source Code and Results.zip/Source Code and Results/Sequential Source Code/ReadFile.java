import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.TreeMap;

public class ReadFile {
	public static void main(String[] args) {
		long startTime = System.nanoTime();
		long endTime = 0;
		TreeMap<String, Integer> frequencyData = new TreeMap<String, Integer>();

		readWordFile(frequencyData);

		endTime = System.nanoTime();
		System.out.println("totalTime = " + (endTime - startTime) / 1000000
				+ " ms");
	}

	public static void readWordFile(TreeMap<String, Integer> frequencyData) {
		// Scanner wordFile;
		Integer count; // The number of occurrences of the word

		File folder = new File(
				"E:\\CSCI 5551 Parallel and Distributed Systems\\HW\\Project\\Code");
		//File folder = new File("TestFolder");
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			File file = listOfFiles[i];
			if (file.isFile() && file.getName().endsWith(".warc")) {
				InputStream in = null;
				BufferedReader bfReader = null;
				try {
					in = new FileInputStream(file);
					bfReader = new BufferedReader(new InputStreamReader(in));
					char[] buffer = new char[128];
					StringBuilder temp = new StringBuilder();
					while (bfReader.read(buffer) > 0) {
						StringBuilder word = null;
						if (temp.length() > 0) {
							word = new StringBuilder(temp);
						} else {
							word = new StringBuilder();
						}
						boolean isWordBoundary = false;
						for (char c : buffer) {
							if (c == ' ') {
								isWordBoundary = true;
							}

							if (!isWordBoundary) {
								word.append(c);
							} else {
								temp.append(c);
							}
						}

						count = getCount(word.toString(), frequencyData) + 1;
						frequencyData.put(word.toString(), count);

					}
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					if (null != bfReader) {
						try {
							bfReader.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}

			}
		}
	}

	public static int getCount(String word,
			TreeMap<String, Integer> frequencyData) {
		if (frequencyData.containsKey(word)) { // The word has occurred before,
												// so get its count from the map
			return frequencyData.get(word); // Auto-unboxed
		} else { // No occurrences of this word
			return 0;
		}
	}
}
